//
//  ProfileHeader.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 24/5/2023.
//

import SwiftUI
import SDWebImageSwiftUI

struct ProfileHeader: View {
    @EnvironmentObject var session: SessionStore
    var user: User?
    var postsCount: Int
    @Binding var following: Int
    @Binding var followers: Int

    
    
    var body: some View {
            VStack{
                if user != nil {
                    WebImage(url: URL(string: user!.profileImageUrl)!)
                        .resizable()
                        .scaledToFit()
                        .clipShape(Circle())
                        .frame(width: 100, height: 100, alignment: .leading)
                    
                    Text(user!.username).font(.headline).bold()
                    
                } else{
                    Color.init(red: 0.9, green: 0.9, blue: 0.9).frame(width: 100, height: 100, alignment: .trailing)
                }

                
            }
            VStack{
                HStack{
                    Spacer()
                    VStack{
                        Text("Посты").font(.footnote)
                        Text("\(postsCount)").font(.title).bold()
                    }.padding(.top, 30).padding(.leading)
                    
                    Spacer()
                    VStack{
                        Text("Подписчики").font(.footnote)
                        Text("\(followers)").font(.title).bold()
                    }.padding(.top, 30).padding(.leading)
                    Spacer()
                    VStack{
                        Text("Подписки").font(.footnote)
                        Text("\(following)").font(.title).bold()
                    }.padding(.top, 30).padding(.leading)
                    Spacer()
                }
                
            }
        }

        
}


//struct ProfileHeader_Previews: PreviewProvider {
//    static var previews: some View {
//        ProfileHeader()
//    }
//}
