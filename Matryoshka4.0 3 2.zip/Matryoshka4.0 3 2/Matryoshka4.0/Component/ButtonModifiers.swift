//
//  ButtonModifiers.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 15/5/2023.
//

import SwiftUI

struct ButtonModifiers: ViewModifier {
    
    func body(content: Content) -> some View{
        content
            .frame(minWidth: 0, maxWidth: .infinity)
            .frame(height: 20)
            .padding()
            .foregroundColor(.white)
            .font(.system(size: 14, weight: .bold))
            .background(Color(#colorLiteral(red: 0.8705882353, green: 0.0862745098, blue: 0.231372549, alpha: 1)))
            .cornerRadius(5.0)
        
    }
    
}
