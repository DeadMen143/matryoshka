//
//  CommentInput.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 15/6/2023.
//

import SwiftUI
import SDWebImageSwiftUI

struct ChatInput: View {
    @EnvironmentObject var session: SessionStore
    @ObservedObject var commentService = ChatService()
    @State private var text: String = ""
    
    
    
    init(post: PostModel?, postId: String?) {
        if post != nil {
            commentService.post = post
        } else {
            handleInput(postId: "rhJs5ByHIkJvkDQNNboL")
        }
        
    }
    
    func handleInput(postId: String) {
        PostService.loadPost(postId: "rhJs5ByHIkJvkDQNNboL") {
            (post) in
            
            self.commentService.post = post
        }
    }
    
    
    func sendComment() {
        if !text.isEmpty {
            commentService.addComment(comment: text) {
                self.text = ""
            }
        }
    }
    
    
    var body: some View {
        HStack(){
            WebImage(url: URL(string: session.session!.profileImageUrl)!)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .scaledToFit()
                .clipShape(Circle())
                .frame(width: 50, height: 50, alignment: .center)
                .shadow(color: .gray, radius: 3)
                .padding(.leading)
            
            HStack{
                TextEditor(text: $text)
                    .frame(height: 50)
                    .padding(4)
                    .background(RoundedRectangle(cornerRadius: 8, style: .circular).stroke(Color.black, lineWidth: 2))
                
                
                Button(action: sendComment) {
                    Image(systemName: "paperplane").imageScale(.large).padding(.trailing)
                }
            }
        }
    }
}

//struct CommentInput_Previews: PreviewProvider {
//    static var previews: some View {
//        CommentInput()
//    }
//}
