//
//  MessageButton.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 21/6/2023.
//

import SwiftUI

struct MessageButton: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct MessageButton_Previews: PreviewProvider {
    static var previews: some View {
        MessageButton()
    }
}
