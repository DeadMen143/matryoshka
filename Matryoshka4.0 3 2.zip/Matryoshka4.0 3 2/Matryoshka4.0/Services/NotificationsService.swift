//
//  NotificationsService.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 22/6/2023.
//

import Foundation
import Firebase
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore


class NotificationsService: ObservableObject {
    @Published var notifications: [Notification] = [] // Хранение уведомлений
    
    func fetchNotifications() {
        // Здесь вы можете добавить логику для получения уведомлений
        // Пример добавления тестовых уведомлений
        notifications = [
            Notification(id: UUID(), message: "У вас новый лайк"),
            Notification(id: UUID(), message: "Ваш пост был прокомментирован"),
            Notification(id: UUID(), message: "Новый подписчик")
        ]
    }
}
