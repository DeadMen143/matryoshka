//
//  PostMainService.swift
//  Flexigram2
//
//  Created by 有賀智貴 on 2022/01/10.
//

import Foundation
import FirebaseAuth
import Firebase
import FirebaseFirestore
import FirebaseStorage
import SwiftUI




class PostMainService: ObservableObject {
    static var following = AuthService.storeRoot.collection("following")
    static var followers = AuthService.storeRoot.collection("followers")
    
    @Published var following = 0
    @Published var followers = 0
    @Published var followCheck = false
    
    @Published var posts: [PostModel] = []
    

    
    func loadUserPosts(userId: String, onSuccess: @escaping(_ posts: [PostModel]) -> Void) {
        
        let db = Firestore.firestore()
        
        db.collection("following").document(Auth.auth().currentUser!.uid).collection("following").getDocuments { (snap, err) in
            
            db.collection("posts").getDocuments { (snapshot, err) in ""
                
                db.collection("posts").getDocuments{
                    (snapshot, error) in
                    
                    guard let snap = snapshot else {
                        print("Error")
                        return
                    }
                    
                    var posts = [PostModel]()
                    
                    for doc in snap.documents {
                        let dict = doc.data()
                        guard let decoder = try? PostModel.init(fromDictionary: dict)
                                
                        else {
                            return
                        }
                        posts.append(decoder)
                    }
                    onSuccess(posts)
                }
            }
            
            func loadUserPosts(userId: String) {
                PostService.loadUserPosts(userId: userId) { [weak self] posts in
                    DispatchQueue.main.async {
                        self?.posts = posts
                    }
                }
                
                follows(userId: userId)
                followers(userId: userId)
            }
            
            func follows(userId: String){
                
                ProfileService.followingCollection(userid: userId).getDocuments{
                    (querysnapshot, err) in
                    
                    if let doc = querysnapshot?.documents {
                        self.following = doc.count
                    }
                }
            }
            
            func followers(userId: String){
                
                ProfileService.followersCollection(userid: userId).getDocuments{
                    (querysnapshot, err) in
                    
                    if let doc = querysnapshot?.documents {
                        self.followers = doc.count
                    }
                }
            }
            
            
        }
    }
}

