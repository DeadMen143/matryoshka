//
//  ContentView.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 15/5/2023.
//

import SwiftUI

struct ContentView: View {
    
    @EnvironmentObject var session: SessionStore
    
    func listen(){
        session.listen()
    }
    
    
    var body: some View {
        
        Group{
            if(session.session != nil){
                HomeView()
            } else{
                SignInView()
            }
        }.onAppear(perform: listen)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
