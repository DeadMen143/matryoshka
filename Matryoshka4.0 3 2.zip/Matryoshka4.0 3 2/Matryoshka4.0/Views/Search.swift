//
//  Search.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 23/5/2023.
//

import SwiftUI

struct Search: View {
    var body: some View {
        Text("SearchView")
    }
}

struct Search_Previews: PreviewProvider {
    static var previews: some View {
        Search()
    }
}
