//
//  CommentView.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 15/6/2023.
//

import SwiftUI

struct ChatView: View {
    @StateObject var commentService = ChatService()
    
    var post: PostModel?
    var postId: String?
    
    
    
    
    var body: some View {
        VStack(spacing: 10){
            ScrollView{
                if !commentService.comments.isEmpty{
                    ForEach(commentService.comments){
                        (comment) in
                        ChatCard(comment: comment).padding(.top)
                    }
                }
            }
            ChatInput(post: post, postId: "rhJs5ByHIkJvkDQNNboL")
        }
        .navigationTitle("Сообщения")
        .onAppear {
            self.commentService.postId = postId
            self.commentService.loadComment()
        }
        .onDisappear{
            if self.commentService.listener != nil {
                self.commentService.listener.remove()
            }
        }
    }
}

