//
//  ChatView.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 21/6/2023.
//

import SwiftUI

struct ChatView: View {
    @StateObject var chatService = ChatService()
    
    var recipientId = ""
    var recipientProfile = ""
    var recipientUsername = ""
    @State private var text: String = ""
    @State private var pickedImage: Image?
    @State private var chatImage: Image?
    @State private var showingActionSheet = false
    @State private var showingImagePicker = false
    @State private var imageData: Data = Data()
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var error: String = ""
    @State private var showingAlert = false
    @State private var alertTitle: String = "О нет!"
    
    
    func errorCheck() -> String? {
        if text.trimmingCharacters(in: .whitespaces).isEmpty
        {
            
            return "Пожалуйста, введите что-то"
        }
        return nil
    }
    
    func clearText(){
        self.text = ""
    }
    
    func sendMessage(){
        if let error = errorCheck() {
            self.error = error
            self.showingAlert = true
            self.clearText()
            return
        }
        
        chatService.sendMessage(message: text, recipientId: recipientId, recipientProfile: recipientProfile, recipientName: recipientUsername, onSuccess: {
            self.clearText()
        }){
            (err) in
            self.error = err
            self.showingAlert = true
            return
        }
    }
    
    func sendPhoto(){
        if !imageData.isEmpty{
            chatService.sendPhotoMessage(imageData: imageData, recipientId: recipientId, recipientProfile: recipientProfile, recipientName: recipientUsername, onSuccess: {}) {
                (err) in
                self.error = err
                self.showingAlert = true
                return
            }
        }
    }
    
    
    
    
    var body: some View {
        VStack{
            if !chatService.chats.isEmpty {
                ScrollView{
                    ScrollViewReader{
                        value in
                        ForEach(chatService.chats, id:\.messageId) {
                            (chat) in
                            
                            VStack{
                                if chat.isPhoto{
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

struct ChatView_Previews: PreviewProvider {
    static var previews: some View {
        ChatView()
    }
}

