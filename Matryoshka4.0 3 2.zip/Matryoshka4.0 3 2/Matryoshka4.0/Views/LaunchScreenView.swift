//
//  LaunchScreenView.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 23/6/2023.
//

import SwiftUI

struct LaunchScreenView: View {
    var body: some View {
        Image("launchscreen")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .edgesIgnoringSafeArea(.all)
    }
}


struct LaunchScreenView_Previews: PreviewProvider {
    static var previews: some View {
        LaunchScreenView()
    }
}

