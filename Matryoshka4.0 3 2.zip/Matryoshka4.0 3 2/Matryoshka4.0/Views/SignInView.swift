//
//  SignInView.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 15/5/2023.
//

import SwiftUI

struct SignInView: View {
    @EnvironmentObject var session: SessionStore
    
    func listen(){
        session.listen()
    }
    
    @State private var email:String = ""
    @State private var password:String = ""
    
    @State private var error:String = ""
    @State private var showingAlert = false
    @State private var alertTitle: String = "О Нет!"
    
    
    func errorCheck() -> String?{
        if email.trimmingCharacters(in: .whitespaces).isEmpty ||
            password.trimmingCharacters(in: .whitespaces).isEmpty
        {
            
            return "Пожалуйста, заполните поля"
        }
        return nil
    
    }
    
    init(){
        for familyName in UIFont.familyNames{
            print(familyName)
            
            for fontName in UIFont.fontNames(forFamilyName: familyName) {
                print("-- \(fontName)")
            }
        }
    }
    func clear(){
        self.email = ""
        self.password = ""
    }
    
    func signIn() {
        if let error = errorCheck(){
            self.error = error
            self.showingAlert = true
            return
        }
        AuthService.signIn(email: email, password: password, onSuccess: {
            (user) in
            self.clear()
        }) {
            (errorMessage) in
            print("Ошибка \(errorMessage)")
            self.error = errorMessage
            self.showingAlert = true
            return
        }
    }
    
    
    
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20){
                Text("Матрёшка").font(.system(size:60, weight: .bold)).foregroundColor(Color(#colorLiteral(red: 0.8705882353, green: 0.0862745098, blue: 0.231372549, alpha: 1)))
                VStack(alignment: .leading){
                    Text("Авторизация").font(.custom("Matreshka", size: 40))
                }
                    FormField(value: $email, icon: "envelope.fill", placeholder: "Электронная почта")
                    FormField(value: $password, icon: "lock.fill", placeholder: "Пароль", isSecure: true)
                    
                Button(action: { signIn()
                    listen()
                    
                }){
                        Text("Войти").font(.title).modifier(ButtonModifiers())
                        
                    }.alert(isPresented: $showingAlert){
                        Alert(title: Text(alertTitle), message: Text(error), dismissButton: .default(Text("OK")))
                    }
                    
                HStack{
                    Text("Первый раз?")
                    NavigationLink(destination: SignUpView()) {
                        Text("Создай себе аккаунт.").font(.system(size: 20, weight: .semibold))
                            .foregroundColor(Color.black)
                    }
                }
                
                
            }.padding()
        }
    }
}

struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
    }
}
