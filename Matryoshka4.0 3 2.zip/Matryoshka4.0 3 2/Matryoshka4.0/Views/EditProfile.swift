//
//  EditProfile.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 16/6/2023.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI

struct EditProfile: View {
    @EnvironmentObject var session: SessionStore
    @State private var username:String = ""
    @State private var profileImage: Image?
    @State private var pickedImage: Image?
    @State private var showingActionSheet = false
    @State private var showingImagePicker = false
    @State private var imageData: Data = Data()
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var error:String = ""
    @State private var showingAlert = false
    @State private var alertTitle: String = "О нет!"
    @State private var bio: String = ""
    
    
    
    init(session: User?){
        
        _bio = State(initialValue: session? .bio ?? "")
        _username = State (initialValue: session?.username ?? "")
    }
    
    func loadImage() {
        guard let inputImage = pickedImage else
            {return}
        
        profileImage = inputImage
    }
    
    
    func errorCheck() -> String?{
        if username.trimmingCharacters(in: .whitespaces).isEmpty ||
            bio.trimmingCharacters(in: .whitespaces).isEmpty ||
            imageData.isEmpty{
            
            return "Please fill in all fields and provide an image"
        }
        return nil
    
    }
    
    func clear(){
        self.bio = ""
        self.username = ""
        self.imageData = Data()
        self.profileImage = Image(systemName: "person.circle.fill")
    }
    
    func edit() {
        if let error = errorCheck(){
            self.error = error
            self.showingAlert = true
            return
        }
        
        guard let userId = Auth.auth().currentUser?.uid else {return}
        
        let storageProfileUserId = StorageService.storageProfileId(userId: userId)
        
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpg"
        
        StorageService.editProfile(userId: userId, username: username, bio: bio, imageData: imageData, metaData: metadata, storageProfileImageRef: storageProfileUserId, onError: {
            (errorMessage) in
            
            self.error = errorMessage
            self.showingAlert = true
            return
        })
        
        self.clear()
    }
    

    
    
    
    var body: some View {
        ScrollView{
            VStack(spacing: 20){
                
                Text("Редактировать профиль").font(.largeTitle)
                
                VStack{
                    Group{
                        if profileImage != nil {
                            profileImage!.resizable()
                                .clipShape(Circle())
                                .frame(width: 200, height: 200)
                                .padding(.top, 20)
                                .onTapGesture {
                                    self.showingActionSheet = true
                                }
                        }else{
                            WebImage(url: URL(string: session.session!.profileImageUrl)!)
                                .resizable()
                                .clipShape(Circle())
                                .frame(width: 100, height: 100)
                                .padding(.top, 20)
                                .onTapGesture {
                                    self.showingActionSheet = true
                                }
                        }
                    }
                }
                
                FormField(value: $username, icon: "person.fill", placeholder: "Имя пользователя")
                FormField(value: $bio, icon: "book.fill", placeholder: "Биография")
                
                Button(action: edit){
                    
                    Text("Редактировать").font(.title).modifier(ButtonModifiers())
                    
                }.padding()
                .alert(isPresented: $showingAlert){
                    Alert(title: Text(alertTitle), message: Text(error), dismissButton: .default(Text("OK")))
                }
                Text("Изменения внесены")
            }
            
        }.navigationTitle(session.session!.username)
            .sheet(isPresented: $showingImagePicker, onDismiss: loadImage){
                ImagePicker(pickedImage: self.$pickedImage, showImagePicker: self.$showingImagePicker, imageData: self.$imageData)
            }.actionSheet(isPresented: $showingActionSheet){
                ActionSheet(title: Text(""), buttons: [.default(Text("Выберите фото")){
                    self.sourceType = .photoLibrary
                    self.showingImagePicker = true
                    
                },
                  .default(Text("Take A Photo")){
                   self.sourceType = .camera
                   self.showingImagePicker = true
                  }, .cancel()
                ])
            }
    }
}

//struct EditProfile_Previews: PreviewProvider {
//    static var previews: some View {
//        EditProfile()
//    }
//}
