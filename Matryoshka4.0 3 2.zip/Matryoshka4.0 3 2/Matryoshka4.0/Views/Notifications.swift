//
//  Notifications.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 23/5/2023.
//

import SwiftUI
import FirebaseAuth
import Firebase






struct Notifications: View {
    var body: some View {
        Text("Notifications")
    }
}

struct Notifications_Previews: PreviewProvider {
    static var previews: some View {
        Notifications()
    }
}
