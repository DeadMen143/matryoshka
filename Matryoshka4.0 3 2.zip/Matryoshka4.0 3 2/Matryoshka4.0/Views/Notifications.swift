//
//  Notifications.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 23/5/2023.
//

import SwiftUI
import FirebaseAuth
import Firebase


struct NotificationsView: View {
    @ObservedObject var notificationsService = NotificationsService()
    
    var body: some View {
        NavigationView {
            List(notificationsService.notifications, id: \.id) { notification in
                NotificationRow(notification: notification)
            }

            .onAppear {
                notificationsService.fetchNotifications()
            }
        }
    }
}

struct NotificationRow: View {
    let notification: Notification
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(notification.message)
                .font(.headline)
        }
        .padding()
    }
}

struct Notifications_Previews: PreviewProvider {
    static var previews: some View {
        NotificationsView()
    }
}
