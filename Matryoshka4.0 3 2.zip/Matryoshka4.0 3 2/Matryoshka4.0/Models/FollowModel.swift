//
//  FollowModel.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 21/6/2023.
//

import Foundation
