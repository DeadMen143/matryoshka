//
//  CommentModel.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 15/6/2023.
//

import Foundation


struct ChatModel: Encodable, Decodable, Identifiable {
    
    var id = UUID()
    var profile: String
    var postId: String
    var username: String
    var date: Double
    var comment: String
    var ownerId: String
    
}
