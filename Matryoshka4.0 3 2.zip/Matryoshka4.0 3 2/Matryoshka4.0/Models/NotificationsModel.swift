//
//  NotificationsModel.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 22/6/2023.
//

import Foundation

struct Notification: Identifiable {
    let id: UUID
    let message: String
}
