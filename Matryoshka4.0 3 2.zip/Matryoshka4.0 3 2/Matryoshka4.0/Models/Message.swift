//
//  Message.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 19/6/2023.
//

import Foundation


struct Message: Encodable, Decodable, Identifiable {
    var id = UUID()
    var lastMessage: String
    var username: String
    var isPhoto: Bool
    var timestamp: Double
    var userId: String
    var profile: String
}
