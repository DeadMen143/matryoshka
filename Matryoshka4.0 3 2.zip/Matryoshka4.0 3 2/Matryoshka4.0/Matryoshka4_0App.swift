//
//  Matryoshka4_0App.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 15/5/2023.
//

import SwiftUI
import FirebaseCore

@main
struct Matryoshka4_0App: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(SessionStore())
        }
    }
}


class AppDelegate: NSObject, UIApplicationDelegate{
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        print("Firebase...")
        FirebaseApp.configure()
        return true
    }
    
}
