//
//  Matryoshka4_0App.swift
//  Matryoshka4.0
//
//  Created by Хачатрян Рафаель Анушаванович on 15/5/2023.
//

import SwiftUI
import FirebaseCore

@main
struct Matryoshka4_0App: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            LaunchScreenView()
                .environmentObject(SessionStore())
                .onAppear {
                    // Здесь можно добавить любую логику или задержку перед переходом к основному интерфейсу приложения
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        appDelegate.showMainInterface()
                    }
                }
        }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        FirebaseApp.configure()
        
        // Инициализируем главное окно приложения
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.makeKeyAndVisible()
        
        return true
    }
    
    func showMainInterface() {
        let contentView = ContentView().environmentObject(SessionStore())
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            self.window = UIWindow(windowScene: windowScene)
            self.window?.rootViewController = UIHostingController(rootView: contentView)
            self.window?.makeKeyAndVisible()
        }
    }
}
