//
//  Matryoshka4_0Tests.swift
//  Matryoshka4.0Tests
//
//  Created by Хачатрян Рафаель Анушаванович on 31/5/2023.
//

import XCTest
@testable import Matryoshka4_0
import SDWebImage

final class Matryoshka4_0Tests: XCTestCase {
    

    class AuthServiceTests: XCTestCase {

        var authService: AuthService!
        
        override func setUpWithError() throws {
            authService = AuthService()
        }

        override func tearDownWithError() throws {
            authService = nil
        }
        
        func testSignUpSuccess() throws {
            let expectation = self.expectation(description: "Sign up success")
            let imageData = UIImage(named: "testImage")!.jpegData(compressionQuality: 0.5)!
            authService.signUp(username: "testUser", email: "test@example.com", password: "test1234", imageData: imageData, onSuccess: { (user) in
                XCTAssertNotNil(user)
                expectation.fulfill()
            }) { (error) in
                XCTFail("Sign up failed: \(error)")
            }
            
            waitForExpectations(timeout: 10, handler: nil)
        }
        
        func testSignUpFailure() throws {
            let expectation = self.expectation(description: "Sign up failure")
            let imageData = UIImage(named: "testImage")!.jpegData(compressionQuality: 0.5)!
            authService.signUp(username: "", email: "", password: "", imageData: imageData, onSuccess: { (user) in
                XCTFail("Sign up succeeded with invalid data: \(user)")
            }) { (error) in
                XCTAssertNotNil(error)
                expectation.fulfill()
            }
            
            waitForExpectations(timeout: 10, handler: nil)
        }

    }


    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        measure {
            // Put the code you want to measure the time of here.
        }
    }

}
